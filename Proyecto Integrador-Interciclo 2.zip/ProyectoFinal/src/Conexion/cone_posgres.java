/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Conexion;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Fabian
 */
public class cone_posgres {
    
    private String Servidor;
    private String Usuarios;
    private String Clave;
    private String Base_de_Datos;
    private String Puerto;
    private String Error;
    
   private Connection Conexion_pg=null;
   private Statement Consultar = null;
   private ResultSet Resultados=null;

    public cone_posgres() {
        
        this.Servidor="localhost";
        this.Usuarios="postgres";
        this.Clave="1234";
        this.Puerto="5432";
        this.Base_de_Datos="Proyecto";
    }
    
    public  Connection Conectar_Base()
    {  
        
     String url= "jdbc:postgresql://"+this.Servidor+":"+this.Puerto+"/"+this.Base_de_Datos;
        try {
            Class.forName("org.postgresql.Driver");
            Conexion_pg = DriverManager.getConnection(url, this.Usuarios,this.Clave);
        } catch (Exception e) {
             this.Error= e.getMessage();
        }
        return Conexion_pg;
    }
    
     public  ResultSet consultar(String Scrip)
    {       
        try {
            this.Consultar = this.Conexion_pg.createStatement();        
            Resultados = this.Consultar.executeQuery(Scrip);
        } catch (Exception e) {
            this.Error= e.getMessage();
        }
            return Resultados;
    }
    
      public String ejecutar_sql(String SQL)
    {  
        this.Error= "";
        try {
            this.Consultar = this.Conexion_pg.createStatement();
            
            this.Consultar.executeUpdate(SQL);   
        } catch (SQLException e) {
            this.Error=e.getMessage();
        }
      return this.Error;
    }
    
      
       public void Cerrar_Base()
    {
        try {
            this.Resultados.close();
            this.Consultar.close();
            this.Conexion_pg.close();
        } catch (Exception e) {
             this.Error= e.getMessage();
        }   
}

}
