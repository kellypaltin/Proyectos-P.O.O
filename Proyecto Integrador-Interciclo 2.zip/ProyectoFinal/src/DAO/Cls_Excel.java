package DAO;

import java.awt.Desktop;
import java.io.*;
import java.math.BigDecimal;
import java.util.*;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


/**
 *
 * @author ginav
 */

public class Cls_Excel {
    private String ruta;
    private String nombre;
    private int num_hojas;
    private String []vec_nom_hojas= new String[10] ;
    Workbook workbook;    
    List<Object[]> modeloE ; 

    public String getRuta() {
        return ruta;
    }

    public void setRuta(String ruta) {
        this.ruta = ruta;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getNum_hojas() {
        return num_hojas;
    }

    public void setNum_hojas(int num_hojas) {
        this.num_hojas = num_hojas;
    }

    public String[] getVec_nom_hojas() {
        return vec_nom_hojas;
    }

    public void setVec_nom_hojas(String[] vec_nom_hojas) {
        this.vec_nom_hojas = vec_nom_hojas;
    }
    
    
   
    
    public Cls_Excel( String ruta ){
        this.ruta="src\\datos\\"+ruta;//archivo.getPath();
        //this.nombre= archivo.getName();
        try {
        File archivo = new File(this.ruta);
        workbook = WorkbookFactory.create(new FileInputStream(archivo));
        this.num_hojas= workbook.getNumberOfSheets();
        sacar_nom_hojas();
            
        } catch (Exception e) {        }
    }
    
    private void sacar_nom_hojas(){
        for (int i = 0; i < num_hojas; i++) {
            vec_nom_hojas[i]= workbook.getSheetName(i);
        }
    }
    
    public List<Object[]> Datos_Hoja(int Num_hoja){
        this.modeloE= new ArrayList<>();
         Sheet hoja = workbook.getSheetAt(Num_hoja);
         
         Iterator filaIterator = hoja.rowIterator(); //creamos una estructura para la informacion contenida en el Excel
            int indiceFila = -1;

            while (filaIterator.hasNext()) {
                indiceFila++;
                Row fila = (Row) filaIterator.next();
                Iterator columnaIterator = fila.cellIterator(); //Recorre la lista ya creada
                Object[] listaColumna = new Object[5000];// un arreglo para capturar informacion
                int indiceColumna = -1;

                while (columnaIterator.hasNext()) {
                    indiceColumna++;
                    Cell celda = (Cell) columnaIterator.next();//hgsdfhghkdshgks

                    if (indiceFila != 0) {
                        if (celda != null) {
                            switch (celda.getCellType()) {

                                case Cell.CELL_TYPE_NUMERIC:
                                    listaColumna[indiceColumna] = celda.getNumericCellValue();
                                    break;

                                case Cell.CELL_TYPE_STRING:
                                    listaColumna[indiceColumna] = celda.getStringCellValue();
                                    break;

                                case Cell.CELL_TYPE_BOOLEAN:
                                    listaColumna[indiceColumna] = celda.getBooleanCellValue();
                                    break;
                                                                                                      
                                default:
                                    listaColumna[indiceColumna] = celda.getStringCellValue();
                                    break;
                            }
                        }
                    }
                }
                if (indiceFila != 0)modeloE.add(listaColumna);
            }
        
        return this.modeloE;
        
    }
}

